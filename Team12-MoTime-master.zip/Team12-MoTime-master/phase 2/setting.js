$(document).ready{
	setbirthday
}
function setbirthday(){
	var yearoptions = "<option>Year</option>";
	var monthoptions = "<option>Month</option>";
	var dayoptions = "<option>Day</option>";
	for (year = new Date().getFullYear(); year > 1900; year--){
  		yearoptions += "<option>"+ year +"</option>";
	}
	for (month = 1; month <= 12; month++){
		if(month < 10){
  			monthoptions += "<option>0"+ month +"</option>";
  		}
  		else{
  			monthoptions += "<option>"+ month +"</option>";
  		}

	}
	for (day = 1; day <= 31; day++){
		if(day < 10){
  			dayoptions += "<option>0"+ day +"</option>";
  		}
  		else{
  			dayoptions += "<option>"+ day +"</option>";
  		}

	}

	document.getElementById("year").innerHTML = yearoptions;
	document.getElementById("month").innerHTML = monthoptions;
	document.getElementById("day").innerHTML = dayoptions;
}

$('.menu .item')
  .tab()
;
