$("#add_task").click(function () {
    $('.ui.modal').modal('show');
});


$("#show_task").click(function () {
    window.open("task.html");
});


