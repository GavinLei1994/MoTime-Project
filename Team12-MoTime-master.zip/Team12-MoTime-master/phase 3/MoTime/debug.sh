#!/usr/bin/env bash
DEBUG=motime:* npm start
