var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  let islogged
  if (req.session.user){
    islogged = 1
    res.redirect('/profile');
  } else {
    islogged = 0
    res.render('home', { l: islogged });
  }
});

module.exports = router;
