var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var session = require('express-session');
//这下面是local写码测试的时候的database路径
// mongoDB setup
var DBURI = (process.env.MONGOLAB_URI || 'mongodb://localhost:7777'); //global var 数据库网址
mongoose.connect(DBURI + '/data');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'DB connection error:'));
// 这下面是架在heroku的时候用的database setting
// var uri = 'mongodb://heroku_kn0scv80:ktvd4s44hidqjnlcmml334rpkv@ds137100.mlab.com:37100/heroku_kn0scv80';
// mongoose.Promise = global.Promise
// mongoose.connect(uri);
// var db = mongoose.connection;
// db.on('error', console.error.bind(console, 'connection error:'));
//User Schemas
var userSchema = new Schema({
  email:     {type: String, unique: true},
  username:  {type: String, unique: true},
  password:  String,
  name: {
    first : {type: String, default: 'N/A'},
    last : {type: String, default: 'N/A'}
  },
  gender: {type: String, default: 'N/A'},
  dob: {type: String, default: 'N/A'},
  goal:{type: String, default: 'N/A'},
  point:{type:Number, default: 0},
  avatar:{type:String, default: '/images/m1.png'},
  followlist:{type: Array, default:[]},//list of following usernames
  // friendrequst: {type: Array, default:[]},
  admin: {type: Number, default:0} //can only set to 1 admin munually
});
var User = mongoose.model('User', userSchema);

//Task Schemas
var taskSchema = new Schema({
  name:         {type: String, default: 'Taskname'},
  start_time:   {type: Date},
  end_time:     {type: Date},
  break_time:   {type: Date}, //考虑一下删掉？
  description: {type:String,default:''},
  owner: {type: String, default: 'guest'},
  complete: {type: Boolean, default: false}
});
var Task = mongoose.model('Task', taskSchema);
/**
 * 上面都是加载的插件，自己加插件就写一起，模仿就可以，当然也要看各自插件的doc怎么说
 */

/**
 * 下面和routes下的文件一一对应 './routes/index' 其实是 './routes/index.js' 省略了后缀
 * 把你们自己写的添加进来，其实相当于载入了你们自己写的插件
 */
var index = require('./routes/index');


/**
 * 无视区开始
 * 浏览一下，挑中文看一下就好
 */
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.locals.pretty = true;
// 看他说的咯
// uncomment after placing your favicon in /public
app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
/**
 * 无视区结束！！！
 */
app.use(session({
   secret:'secret',
   resave:true,
   saveUninitialized:false,
   cookie:{
       maxAge:1000*3600*2 // expire time (unit: ms)
   }}));
app.use(function(req, res, next){
 res.locals.user = req.session.user;
 var err = req.session.error;
 if (err) {
   res.send(err);
   return;
 }
 next();
});
/**
 * 主区域
 */
// 示例
// app.get('/testpage', function(req, res){
    // 用户发送get请求到 /testpage 时干的事 （相当于用户点击 motime.com/testpage)
    // 注意这里是exactly /testpage  如果/testpage/happy 就和这个无关了
    // do something;

    // 如果用静态html
    // res.sendFile('./views/testpage.html');  // 只是示范，实际并没有这个文件
    //
    // 如果用动态jade模板
    // 注意'testpagejade'对应的其实是'./views/testpagejade.jade'，
    // 但是前面都设置好了所以这么搞就可以了
    // somedata是个json object传给testpagejade，
    // jade模板可以根据你的somedata显示不同的内容。看我的testpagejade范例
    // 如果不给somedata也可以，相当于静态页面。
    // res.render('testpagejade');
    // const somedata = {text1: "test", text2: "tttt"};
    // res.render('testpagejade', somedata);
    // 或者可以重定向
    // res.redirect('/users');
// });
// app.get('/home', function(req,res){
//   res.render('home');
// }) 没有/home这个东西 主页的地址是'/'
app.get('/profile', function(req,res){
  if (req.session.user) {//logged in
    let user = req.session.user;
    let username = user.username;
    res.redirect('/profile/'+username);
  } else { //not logged in
    res.redirect('/log_in');
  }
})
app.get('/profile/:usrn', function(req,res){
  // console.log('REQ:',req.session.user);
  if(req.session.user==undefined){
    return res.redirect('/');
  }
  let usrn = req.params.usrn;
  //Verify that this user exists.
  User.findOne({username: usrn}, function(err, result){
    if(!result || err){
      //we dont find this user..
      res.redirect('/')
    }else{
      // result found, NOTE: result==page owner here
      if (req.session.user.username == result.username){
        //当前用户是page owner
        console.log('当前用户是page owner');
        res.render('profile',{
          username: result.username,
          point: result.point,
          name: result.name.first + ' ' + result.name.last,
          gender: result.gender,
          dob: result.dob,
          goal: result.goal,
          avatar: result.avatar,
          isowner:1
        })
      }
      else{
        //当前用户不是page owner
        console.log('当前用户不是page owner')
        console.log(req.session.user);
        res.render('profile',{
          username: result.username,
          point: result.point,
          name: result.name.first + ' ' + result.name.last,
          gender: result.gender,
          dob: result.dob,
          goal: result.goal,
          avatar: result.avatar,
          isowner:0
        })
      }
    }
  })
})
app.post('/todaytask', function(req, res){
  // let owner = req.param('owner');
  let data = req.body;
  let owner = data['owner'];
  // console.log(owner);
  Task.find({owner: owner}).sort({end_time:1}).exec(function(err, result){
    if(!err && result){
      // console.log('result sent: ', result);
      res.send(result);
    }
  });
});
app.post('/following', function(req, res){
  let data = req.body;
  let username = data['owner'];
  User.findOne({username: username}, function(err, result){
    if(!err && result){
      // console.log('result sent: ', result);
      let d = [];
      let f = result.followlist;
      for(i=0;i<f.length;i++){
        User.findOne({username:f[i]},function(err, result){
          if(result){
            d.push(result);
          }else{

          }
        })
      }
      setTimeout(function(){
        res.send(d);
      }, 5000);
    }
  });
});
app.get('/add_task', function(req,res){
  if (req.session.user){
    res.render('add_task');
  }else{
    res.redirect('/');
  }
})
app.get('/task', function(req,res){
  if (req.session.user) {//logged in
    res.redirect('profile');
  } else { //not logged in
    res.redirect('/');
  }
})

app.get('/task/:task_id', function(req,res){
  if (req.session.user) {
    Task.findById(req.params.task_id, function (err, thetask) {
      if(thetask){
        console.log("Opening task (" + thetask.name + ") with ID (" + thetask._id + ")");
        res.render('task',{
          name: thetask.name,
          start_time: thetask.start_time,
          end_time: thetask.end_time,
          break_time: thetask.break_time,
          owner: req.session.user.username,
        })
      }else{
        console.log("Invalid Task ID:" + req.params.task_id);
        res.redirect('/');
      }
    })
  } else { //not logged in
    res.redirect('/log_in');
  }
})

app.post('/taskui', function(req, res){
  let data = req.body;
  let task_id = data['id'];
  Task.findById(task_id, function (err, result){
    if(!err && result){
      res.send(result);
    }
  });
});

app.put('/task/:task_id', function(req,res){
  let query = {};
  let new_query = {};

  var task_id = req.params.task_id;
  query._id = task_id;
  new_query.complete = true;

  var username = req.session.user.username;
  User.findOne({username: username}, function(err, result){
    console.log("分数为1(" + result.point + ")");
    User.findOneAndUpdate({username: req.session.user.username}, {point: result.point + 1}, function(err, result){});
  });

  Task.findById(task_id, function (err, result) {
    if(result){
      Task.findOneAndUpdate(query, new_query, function(err, writeResult1){});
      console.log("Task (" + result.name + ") is completed now");
      res.status(200).send(result);
    }
  });
})

app.delete('/task/:task_id', function(req,res){
  let query = {};
  var task_id = req.params.task_id;
  query._id = task_id;
  Task.findOne(query, function (err, result) {
    if(result){
      Task.deleteOne(query, function(err){});
      console.log("Task (" + result.name + ") is delete now");
      res.status(200).send(result);
    }else{
      console.log('Task ('+ query._id + ') doesnt exist');
      res.sendStatus(404);
    }
  });
})

app.get('/search', function(req,res){
  if (req.session.user){
    res.render('search');
  }else{
    res.redirect('/');
  }
})
app.get('/setting', function(req,res){
  if (req.session.user){
    User.findOne({username: req.session.user.username}, function(err,result){
      if(result){
        res.render('setting',{avatar: result.avatar});
      }
    })
  }else{
    res.redirect('/');
  }
})
app.get('/log_out', function(req,res){
  console.log('LOG OUT FUNCTION');
  req.session.destroy();
  res.redirect('/')
})
app.get('/sign_up', function(req,res){
  if (req.session.user){
    res.redirect('/profile');
  }else{
    res.render('sign_up');
  }
})
app.get('/log_in', function(req,res){
  if (req.session.user){
    res.redirect('/profile')
  }
  else{
    res.render('log_in');
  }
      // res.render('log_in');
    // }
  // });
})
app.post('/follow', function(req, res){
  let befollowed = req.body['befollowed'];
  console.log(req);
  let follower = req.session.user.username;
  console.log(follower);
  let flist = [];
  User.findOne({username: follower}, function(err,result){
    if(result){
      console.log(result.followlist);
      flist = result.followlist;
      console.log(flist);
      let s = -1;
      for(i=0;i<flist.length;i++){
        if(flist[i]==befollowed){
          console.log(befollowed);
          s = i;
        }
      }
      if(s>-1){
        console.log('alreadyfollowed');
      }else{
        console.log('push');
        flist.push(befollowed);
      }
      User.updateOne({username: follower}, {followlist: flist},function(err, raw){
        if(raw.ok==1){
          console.log('success');
          return res.send('success');//for success
        }
        else{
          console.log('fail');
          return res.send('fail');//for fail.
        }
      });
    }
  })

})
app.post('/unfollow', function(req, res){
  let unfollowed = req.body['unfollowed'];
  let follower = req.session.user.username;
  let flist = [];
  User.findOne({username: follower}, function(err,result){
    if(result){
      flist = result.followlist;
      let s = -1;
      for(i=0;i<flist.length;i++){
        if(flist[i]==unfollowed){
          s = i;
        }
      }
      if (s > -1) {
         flist.splice(s, 1);
      }else{

      }
      User.updateOne({username: follower}, {followlist: flist} ,function(err, raw){
        if(raw.ok==1){
          console.log('success');
          return res.send('success');//for success
        }
        else{
          console.log('fail');
          return res.send('fail');//for fail.
        }
      });
    }
  })
});
app.put('/setavatar', function(req, res){
  // let avatar = req.param('avatar');
  let avatar = req.body['avatar'];
  console.log(req.session.user.username);
  User.updateOne({username:req.session.user.username},{avatar: avatar}, function(err,raw){
    if(raw.ok==1){
      console.log('setavatar success');
      res.send('success');
    }else{
      res.send('fail');
    }
  });
});

//change the password of the current user
app.put('/changepw', function(req, res){
  let newpw = req.body['newpw'];
  console.log(req.session.user.username);
  User.updateOne({username:req.session.user.username},{password: newpw}, function(err,raw){
    if(raw.ok==1){
      console.log('changepw success');
      res.send('success');
    }else{
      res.send('fail');
    }
  });
});
app.put('/updateinfo', function(req, res){
  console.log('asada');
  let info = {};
  if(req.body['firstname']){
    info.name = {};
    info.name.first = req.body['firstname'];
    if(req.body['lastname']){
      info.name.last = req.body['lastname'];
    }
  }
  console.log(info);
  if(req.body['birthday']){
    info.birthday = req.body['birthday'];
  }
  if(req.body['gender']){
    info.gender = req.body['gender'];
  }
  if(req.body['goal']){
    info.goal = req.body['goal'];
  }
  console.log(req.session.user.username);
  console.log(info);
  User.updateOne({username:req.session.user.username},info, function(err,raw){
    if(raw.ok==1){
      console.log('updateinfo success');
      res.send('success');
    }else{
      res.send('fail');
    }
  });
});
app.post('/search_user', function(req,res){
  let data = req.body;
  let wanted = data['search_username'];
  let flist = req.session.user.followlist;
  let d = {};
  let s = -1;
  for(i=0;i<flist.length;i++){
    if(flist[i]==wanted){
      s = i;
    }
  }
  console.log(s);
  if(s>-1){//we found what we want in followlist
    d.isfollowed = 1; //therefore means this user must exist.
    d.found = 1;
  }else{
    d.isfollowed = 0;
  }
  User.findOne({username : wanted}, function(err, result){
    if(result){
      d.user = result;
      d.found = 1;
      res.send(d);
    }
    else{
      d.found = 0;
      res.send(d);
    }
  });
});
app.post('/search_task', function(req,res){
  let owner = req.session.user.username;
  // console.log(owner);
  console.log(owner);
  Task.find({owner: owner}).sort({end_time:1}).exec(function(err, result){
    if(!err && result){
      // console.log('result sent: ', result);
      res.send(result);
    }
  });
});

app.post('/add_task', function(req, res){
  let data = req.body;
  let task_name = data['task_name'];

  let start_date = data['start_date'];
  let end_date = data['end_date'];

  let break_hour = data['break_hour'];
  let break_minute = data['break_minute'];
  let owner = req.session.user.username;

  var start_time = new Date(start_date);
  var end_time = new Date(end_date);
  var break_time = new Date(start_time + (end_time - start_time)/2 );

  //set date if input is not valid date
  var current_time = new Date();
  var tmr_time = new Date();
  tmr_time.setDate(tmr_time.getDate() + 1);
  if ( isNaN( start_time.getTime() ) ) {
    // start_time is not valid
    start_time = current_time;
  }
  if ( isNaN( end_time.getTime() ) ) {
    // end_time is not valid
    end_time = tmr_time;
  }
  if ( isNaN( break_time.getTime() ) ) {
    // break_time is not valid
    current_time.setDate(current_time.getDate() + 0.5);
    break_time = current_time;
  }

  var newTask = new Task({
    name:         task_name,
    start_time:   start_time,
    end_time:     end_time,
    break_time:   break_time,
    owner: owner
  });

  newTask.save();
  console.log('Created (' + newTask.name + ')');
  var task_id = newTask._id;
  //console.log('这个task id是:' + newTask._id);
  //console.log('Add new task success: ' + newTask.name);
  res.redirect('/task/' + task_id)
});
app.post('/sign_up', function(req, res){
  let data = req.body;
  // console.log('POSTED',data);
  console.log(data['username']);
  let username = data['username'];
  let password = data['password'];
  let email = data['email-address'];
  let firstname = data['first-name'];
  let lastname = data['last-name'];
  let gender = data['gender'];
  let dob = data['birthday'];
  let goal = data['goal'];
  var newUser = new User({
    email:    email,
    username: username,
    password: password,
    name:{
      first: firstname,
      last: lastname
    },
    gender: gender,
    dob: dob,
    goal: goal
  });
  User.findOne({email:email}, function(err, result){
    // console.log('err',err);
    // console.log('result',result);
    if(result){
      //重复email
      console.log('sign up uf0 ef1');
      res.render('sign_up', {
        uf: 0,
        ef: 1
      });
    }
    else{
      //没重email
      User.findOne({username:username}, function(err,result){
        if(result){
          //重复username
          console.log('sign up uf1 ef0');
          res.render('sign_up', {
            uf: 1,
            ef: 0
          });
        }
        else{
          //没重复username
          console.log('log in sign up success');
          username_found = 0;
          newUser.save();
          res.redirect('/log_in');
        }
      })
    }
  })
  // console.log('SAVED');
  // res.render('log_in');
  // res.redirect('/log_in');
  // console.log('tried')
  // res.send('sign_up');
});
app.post('/log_in', function(req, res){
  let data = req.body;
  // console.log('POSTED',data);
  // console.log(data['username']);
  let username = data['username'];
  let password = data['password'];
  User.findOne({username:username}, function(err,result){
    // console.log(result)
    if (!err && result) {
      if (result.password == password){
        // console.log('logged',result.username)
        req.session.user = result
        usrname = result.username;
        res.redirect('/profile/' +usrname)
      }
      else {
        console.log('WRONG PW');
        res.render('log_in',{
          wrongpw:1
        });
      }
    }
    else{
      res.render('log_in',{
        nousername:1
      });
    }
  });
  // res.send('sign_up');
});
/**
 * 但是！！！
 * 除了很简单的页面（只有一行res.render),
 * 上面这些东西最好不要写在这个文件里，写到单独的文件去
 * 黑人问号？
 * 往下看
 */

/**
 * 模仿着写，和上面 var index = require('./routes/index'); 联动起来
 */
// 把用户到 '/'(get, post or others) 的请求转到具体的模组去（上面require的routes下面的文件）
app.use('/', index);
// 把用户到 '/'(get, post or others) 的请求转到具体的模组去（上面require的routes下面的文件）
// 包括 '/users' 下属的所有， e.g. '/users/login', '/users/happy/happy'...全部会被转给
// users(./routes/users.js)处理
// app.use('/users', users);
// 具体看 routes/users.js


/**
 * 以下全部无视就好了
 */
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
