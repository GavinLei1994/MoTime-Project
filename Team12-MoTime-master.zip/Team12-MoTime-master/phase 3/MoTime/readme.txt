前提条件：
    电脑装有 node
正常启动：
    $ npm start
debug启动（写代码时推荐总是这样启动）：
    $ ./debug.sh    if permission denied, do $ chmod 755 debug.sh
本地网址：
    localhost:3000 或者
    127.0.0.1:3000 <-- 推荐这个

app.js
    主文件，主要用来加插件，最好不要在这里面写大量代码
bin/
    MAGIC, DO NOT TOUCH
public/
    前端文件 js, css, image, NO HTML
routes/
    后台代码，推荐一个大页面对应一个单独的文件，便于管理与分工
views/
    网页，可以使用静态html，但是我推荐使用jade，很强，可以看我写的example
package.json
    依赖文件，如果每次安装所需插件都用 $ npm --save install module_name 的话，就可以无视这个文件了。
readme.txt
    这个文件。下面的网址是这个expressjs和jade的网站。学一下有问题问我。


step 1: 看app.js
step 2: 看routes/users.js
step 3: 看views/sample/


https://expressjs.com/
http://html2jade.org/
jade-lang.com
