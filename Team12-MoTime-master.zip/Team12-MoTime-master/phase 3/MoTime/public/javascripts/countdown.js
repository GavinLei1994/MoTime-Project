function countdown(date, id){

var countDownDate = date.getTime();
var now = new Date().getTime();
var distance = countDownDate - now;
// Update the count down every 1 second
var x = setInterval(function() {

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById(id).innerHTML = "Time left: " + days + "days " + hours + "hours "+ minutes + "minutes " + seconds + "seconds ";
  distance -= 1000;
  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById(id).innerHTML = "Time left: TIME UP";
    document.getElementById(id).style.color = 'red';
  }
}, 1000);
return x;
}
