//这是开网页的时候会传进来的根据当前用户生成的data
//只是一个模版 但到时候传进来的东西就是这么个格式
 /*let data = {
  email: 'abc123@csc.com',
  username: 'tz925',
  name: {
    first : 'Thomas',
    last : 'Zhou'
  },
  gender: '1',
  dob: {
    month: '09',
    day: '25',
    year: '1995',
  }
  goal:'no goals ehehe',
  point: 10,
  friendlist: ['nacl','POW'],
  friendrequst: ['gavin'],
  todaytasklist:[这里不用管 你们想想怎么把该显示的姓名什么的对应在profile里正确的位
  置显示出来就行]
}

//这是改变from to date 取得时间段内task的时候传进来的data
let data = {
  requestedtasklist:[]
}*/
$(document).ready(function() {
  //load in js for countfown
  $.getScript('/javascripts/countdown.js', function()
{
    // script is now loaded and executed.
    // put your dependent JS here.
    //load好就开始跑的
    //开始获取本用户当天的task list
    let alltask = [];
    let url = $(location).attr('href');
    let owner = url.replace(/.*\/profile\/(.*)/ ,'$1');
    let d = {};
    d.owner = owner;
    $.ajax({
        url: '/following',
        type: 'POST',
        data: d,
        dataType: 'json',
        success: function(data){
          if (data) {
            data.forEach(function(element){
              let f = '<div class="ui text container"><a href="/profile/'+element.username+
              '"><img src="'+element.avatar+'" class="ui mini circular image inline"><span> '+
              element.username+'</span></a><p>Point: '+ element.point +'</p></div><div class="ui fitted divider"></div>';
              $('#followlist').append(f);
            });
          }
        }});
    let allcountdown = [];
    $.ajax({
        url: '/todaytask',
        type: 'POST',
        data: d,
        dataType: 'json',
        success: function(data){
          if (data) {
            // $('#taskfeed').append('<p>AAAAHAHAHAHAHAHAHA</p>')
            // console.log('received: ', data);
            let today = new Date();
            let tyear = today.getFullYear();
            let tmonth = today.getMonth();//0是一月 11是十二月
            let tday = today.getDate();
            // console.log('Today date:', today);
            //we can save all tasks of user in var alltask so we dont need to ajax again
            alltask = data;
            // let ddlind = 0;
            for (i=0;i<data.length;i++){
              let task = data[i];
              let end_time = new Date(task.end_time);
              let start_time = new Date(task.start_time);
              let y = end_time.getFullYear();
              let m = end_time.getMonth();//0是一月 11是十二月
              let d = end_time.getDate();
              // console.log(a.getDate())
              if (y==tyear && m==tmonth && d==tday){
                //今天deadline的task
                var c;
                let t = '<a href="' + '/task/'+ task._id + '"><div class="ui segment task">'+
                '<h3>' + task.name + '</h3>'+
                '<div class="ui divider"></div>'+
                '<p class="deadline">Start time: '+  start_time.toLocaleString() + '</p>'+
                '<p class="deadline">Deadline: '+ end_time.toLocaleString() + '</p>'+
                '<p id="' + task._id + '"></p>'
              '</div></a>';
                $('#taskfeed').append(t);
                c = countdown(end_time, task._id);
                allcountdown.push(c);
                // ddlind+=1;
              }
            }
          }
        }});
    $('#findtask').click(function(){
      allcountdown.forEach(function(element){
        clearInterval(element);
      });
      $('#taskfeed').html(' ');
      let from = $('#fromdate').val().match(/^[0-9]{4}(0[1-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])$/g);
      let to = $('#todate').val().match(/^[0-9]{4}(0[1-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])$/g);
      //需添加validation check!!!! str.match(/ain/g);
      if(!from || !to){
        $('#findtaskerror').removeClass('hidden');
        $('#findtaskerror').html('<p>Please enter valid date<p>');
        return;
      }else if(parseInt(from)>=parseInt(to)){
        $('#findtaskerror').removeClass('hidden');
        $('#findtaskerror').html('<p>Date range is not valid<p>');
        return;
      }
      else{
        $('#findtaskerror').addClass('hidden');
        from = from[0];
        to = to[0];
      }
      let fromyear = parseInt(from.substring(0,4));
      let frommonth = parseInt(from.substring(4,6))-1;
      let fromdate = parseInt(from.substring(6,8));
      let toyear = parseInt(to.substring(0,4));
      let tomonth = parseInt(to.substring(4,6))-1;
      let todate = parseInt(to.substring(6,8));
      let from_time = new Date(fromyear,frommonth,fromdate,0,0,0,0);
      let to_time = new Date(toyear,tomonth,todate,0,0,0,0);
      let fromtime = from_time.getTime();
      let totime = to_time.getTime();
      // let ddlind = 0;
      for (i=0;i<alltask.length;i++){
        let task = alltask[i];
        let end_time = new Date(task.end_time);
        let start_time = new Date(task.start_time);
        let endtime = end_time.getTime();
        // console.log(a.getDate())
        if (fromtime<=endtime && endtime<=totime){
          //task that fit in the time frame.
          let t = '<a href="' + '/task/'+ task._id + '"><div class="ui segment task">'+
          '<h3>' + task.name + '</h3>'+
          '<div class="ui divider"></div>'+
          '<p class="deadline">Start time: '+  start_time.toLocaleString() + '</p>'+
          '<p class="deadline">Deadline: '+ end_time.toLocaleString() + '</p>'+
          '<p id="' + task._id + '"></p>'
        '</div></a>';
          $('#taskfeed').append(t);
          c = countdown(end_time, task._id);
          allcountdown.push(c);
          // ddlind+=1;
        }
      }

    })
});

})
