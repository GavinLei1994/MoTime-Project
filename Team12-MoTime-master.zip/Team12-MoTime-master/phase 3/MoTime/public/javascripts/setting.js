$(document).ready(function() {
  $('select.dropdown').dropdown();
	$('#setavatar').click(function(){
		let d = {};
		d.avatar = $('#avatar_dropdown').val();
		console.log(d.avatar);
		$.ajax({
        url: '/setavatar',
        type: 'PUT',
        data: d,
        dataType: 'json',
				success:function(data){}
    });
		let t = "<div class='ui message success'>Set avatar Success!</div>";
		$('#account').append(t)
	});
	$('#changepw').click(function(){
		var newpassword = $('#newpw').val();
		var confirm = $('#confirm').val();
 		if (newpassword != confirm){
			$('#pwerror').removeClass('hidden');
        	$('#pwerror').html('<p>Password does not match<p>');
        }
		let d = {};
		d.newpw = newpassword;
		$.ajax({
        url: '/changepw',
        type: 'PUT',
        data: d,
        dataType: 'json',
				success:function(data){}
    });
		let t = "<div class='ui message success'>Success!</div>";
		$('#security').append(t)
	});
	$('#updateinfo').click(function(){
		let d = {};
		let firstname = $('#firstname').val();
		let lastname = $('#lastname').val();
		let birthday = $('#birthday').val();
		let gender = $('#gender').val();
		let goal = $('#goal').val();
		if(firstname!=''){
			d.firstname = firstname;
		}
		if(lastname!=''){
			d.lastname = lastname;
		}
		if(birthday!=''){
			d.birthday = birthday;
		}
		if(gender!=''){
			d.gender = gender;
		}
		if(goal!=''){
			d.goal = goal;
		}
		console.log(d);
		$.ajax({
        url: '/updateinfo',
        type: 'PUT',
        data: d,
        dataType: 'json',
				success:function(data){}
	  });
		let t = "<div class='ui message success'>Update success!</div>";
		$('#account').append(t)
	});
	$('.menu .item')
	  .tab()
})
