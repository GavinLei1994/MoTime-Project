$(document).ready(function() {

$("#task_detail").click(function () {
    $('.ui.modal').modal('show');
})


$("#add_task").click(function () {
	var url = "/task"; // the script where you handle the form input.

	$.ajax({
		type: "POST",
		url: url,
		data: $("#task_info").serialize(), // serializes the form's elements.

		success: function(data)

		{

        }

	});
})


$('.ui.form')
  .form({
    onSuccess: function(){

    },
    fields: {

      task_name: {
        identifier: 'task_name',
      },

      start_year: {
        identifier: 'start_year',
        rules: [
          {type   : 'regExp[/^[0-9]{1,4}$/]', prompt : 'Please enter a valid start year'}
        ]
      },

      start_month: {
        identifier: 'start_month',
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid start month'}
        ]
      },

      start_date: {
        identifier: 'start_date',
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid start date'}
        ]
      },

      start_hour: {
        identifier: 'start_hour',
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid start hour'}
        ]
      },
      
      start_minute: {
        identifier: 'start_minute',
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid start minute'}
        ]
      },
      
      len_day: {
        identifier: 'len_day',
        rules: [
          {type   : 'regExp[/^[0-9]{1,4}$/]', prompt : 'Please enter a valid task length'}
        ]
      },

      len_hour: {
        identifier: 'len_hour',
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid task length'}
        ]
      },

      len_minute: {
        identifier: 'len_minute',
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid task length'}
        ]
      },

      break_hour: {
        identifier: 'break_hour',
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid break time'}
        ]
      },

      break_minute: {
        identifier: 'break_minute',
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid break time'}
        ]
      }
    }
});


})



