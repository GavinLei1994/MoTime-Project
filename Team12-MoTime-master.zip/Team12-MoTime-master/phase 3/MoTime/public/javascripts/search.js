var lst;



$(document).ready(function(){
  $('.menu .item').tab();


  $("#search_user").click(function(){
    $('.ui.dimmer').addClass('active');
    var url = "/search_user";
    var d = {};
    username = $('#result_u').val();
    d.search_username = username;
    // console.log("get", d.username);
    $.ajax({
      type: "POST",
      url: url,
      data: d, // serializes the form's elements.
      dataType: 'json',
      success: function(data){
        $('.ui.dimmer').removeClass('active');
        if(data.found==0){
          $('#result').html('<div class = "content" align = "center"><p style = "font-size:40px">No such user</p><div>');
          $('.ui.modal').modal('show');
        }
        else{
          // if(data.isfollowed == 1){//已经follow 加unfollow按钮
          //
          // }else{//没有follow 加 follow 按钮
          //
          // }
          //想办法知道result有没有被当前用户follow 考虑添加followed_by_list在schema里面来简便处理。
          //根据被follow的情况显示不同的button
          $('#result').html('<div class="image content" align = "center">' +'<div class="ui header">User Found</div>'+ '<img class="ui medium circular image" src="' +
           data.user.avatar + '">'+ '<div class="description">' + "<a href='/profile/" +
           data.user.username +
           //这边我就不仔细弄了 你自己看看怎么排版弄的好看点吧
           //反正头像要有 整个框的外面都套上<a>这样点哪儿都能传送
           "'>" +"<p style='font-size:40px;'>" + data.user.username + '</p></a>' + '<br></br>' +
           '<div class="ui small submit button blue" id="follow">Follow</div>'+
           '<div class="ui small submit button blue" id="unfollow">Unfollow</div>'+
           '</div></div>');
          $('.ui.modal').modal('show');
           $('#follow').click(function(){
             let d = {};
             //暂时这么弄 具体看你到时候怎么排的版
             let befollowed = $(this).prev().html();
             d.befollowed = username;
             $.ajax({
               type: "POST",
               url: '/follow',
               data: d, // serializes the form's elements.
               dataType: 'json',
               success: function(data){
                 //这边有问题 接不到callback data
                 }

             })
           })
           $('#unfollow').click(function(){
             let d = {};
             //暂时这么弄 具体看你到时候怎么排的版
             let unfollowed = $(this).prev().html();
             d.unfollowed = username;
             $.ajax({
               type: "POST",
               url: '/unfollow',
               data: d, // serializes the form's elements.
               dataType: 'json',
               success: function(data){
                 //这边有问题 接不到callback data
                 }

             })
           })

        }
      }
    });
  })

  $("#search_task").click(function(){
    $('.ui.dimmer').addClass('active');
    var url = "/search_task";
    var d = {};
    var taskname = $('#result_t').val();
    // console.log("get", d.username);
    $.ajax({
      type: "POST",
      url: url,
      data: d, // serializes the form's elements.
      dataType: 'json',
      success: function(data){
        $('.ui.dimmer').removeClass('active');
        if(data.length == 0){
          $('#result').html('<div class = "content" align = "center"><p style = "font-size:40px">Have no task</p><a href ="/add_task" class="ui small submit button blue">Create a New Task Now</div><div>');
          $('.ui.modal').modal('show');
        }
        else{
          var tasklist =[];
          data.forEach(function(element){
            if(element.name.includes(taskname)){
              var task = [];
              task.push(element.name);
              task.push(element.start_time);
              task.push(element._id);
              tasklist.push(task);
            }
          });

          if(tasklist.length < 1){
            $('#result').html('<div class = "content" align = "center"><p style = "font-size:40px">No such task</p><a href ="/add_task" class="ui small submit button blue">Create a New Task Now</div><div>');
            $('.ui.modal').modal('show');
          }
          else{
            $('#result').html('<div class = "content" align = "center">');
            let today = new Date();
            tasklist.forEach(function(element){
              let name = element[0];
              let start_time = new Date(element[1]);
              let id =  element[2];
              if(start_time > today){
                let t = '<a href="' + '/task/'+ id + '"><div class="ui segment task">'+
                '<h3>' + "Coming Task" + '</h3>'+
                '<div class="ui divider"></div>'+
                '<p> Task name: ' + name + '</p>' +
                '<p class="deadline">Start time: '+  start_time.toLocaleString() + '</p>'+
                '<p id="' + id + '"></p>'+
                '</div></a>';
                $('#result').append(t);
              }
              else{
                let t = '<a href="' + '/task/'+ id + '"><div class="ui segment task">'+
                '<h3>' + "Old Task" + '</h3>'+
                '<div class="ui divider"></div>'+
                '<p> Task name: ' + name + '</p>' +
                '<p class="deadline">Start time: '+  start_time.toLocaleString() + '</p>'+
                '<p id="' + id + '"></p>'+
                '</div></a>';
                $('#result').append(t);

              }
            });

            $('#result').append('</div>');
            $('.ui.modal').modal('show');
          }
        }
      }
    })
  });
})