$(document).ready(function() {


$("#cancel").click(function () {
	window.history.back();
})

$('#rangestart').calendar();

$('#rangeend').calendar();


// $("#add_task").click(function () {
// 	var url = "/add_task"; // the script where you handle the form input.

// 	$.ajax({
// 		type: "POST",
// 		url: url,
// 		data: $("#task_info").serialize(), // serializes the form's elements.

// 		success: function(data)
// 		{

//     }

// 	});
// })


$('.ui.form')
  .form({
    onSuccess: function(){

    },
    fields: {

      task_name: {
        identifier: 'task_name',
      },

      start_date: {
        identifier: 'start_date',
      },

      end_date: {
        identifier: 'end_date',
      },

      break_hour: {
        identifier: 'break_hour',
        optional: true,
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid break time'}
        ]
      },

      break_minute: {
        identifier: 'break_minute',
        optional: true,
        rules: [
          {type   : 'regExp[/^[0-9]{1,2}$/]', prompt : 'Please enter a valid break time'}
        ]
      }
    }
});


})



