$(document).ready(function() {
var patharray = window.location.pathname.split( '/' );
var task_id = patharray[patharray.length - 1];

$.getScript('/javascripts/countdown.js', function(){
  $.ajax({
    method: 'POST',
    url: '/taskui',
    data: "&id=" + task_id, // serializes the form's elements.
    success: function(data){
      var delete_button = $(".ui.deletebutton");
      delete_button.html('');
      delete_button.append('\
        <button id="delete_task" class="ui large red button">Delete Task</button>\
        ');

      var uibuttons = $(".ui.button_list");
      uibuttons.html('');
      if (data.complete){
        $("#task_title").append('\
          <div class="ui teal tag label">COMPLETED</div>\
          ');
      }else{
        $("#task_title").append('\
          <div class="ui orange tag label">TODO</div>\
          ');
        uibuttons.append('\
          <button id="finish_task" class="ui large green button">Task Complete</button>\
          ');
      }
    }
  });
});

$('.ui.button_list').on('click', '#finish_task', function() {
  var url = '/task/' + task_id; // the script where you handle the form input.
  $.ajax({
    method: 'PUT',
    url: url,
    // data: "&id=" + task_id, // serializes the form's elements.
    success: function(data){
      location.reload();
    }
  });

});

$('.ui.deletebutton').on('click', '#delete_task', function() {
  var url = '/task/' + task_id; // the script where you handle the form input.
  $.ajax({
    method: 'DELETE',
    url: url,
    success: function(data){
      location.reload();
    }
  });

});



})



