# Teamwork
to be used for your teamwork on the project
Powered by:
- Semantic-UI
	need nodeJS installed.
- express
- jade
- node.js